from setuptools import setup

setup(name='localnow',
      version='1.1.5',
      description='Returns a PyTZ object with the local time & timezone',
      url='https://github.com/iPadGuy/pylocalnow',
      author='iPad Guy',
      author_email='ipad.guy.100@gmail.com',
      license='MIT',
      #packages=['localnow'],
      install_requires=[
            'pytz',
      ],
      scripts=['bin/localnow'],
      zip_safe=False
)


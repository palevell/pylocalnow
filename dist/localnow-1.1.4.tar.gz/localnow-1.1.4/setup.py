from setuptools import setup

setup(name='localnow',
      version='1.1.4',
      description='Returns a PyTZ object with the local time & timezone',
      url='https://github.com/iPadGuy/pylocalnow',
      author='iPad Guy',
      author_email='ipad.guy.100@gmail.com',
      license='MIT',
      #packages=['localnow'],
      install_requires=[
            'pytz',
      ],
      zip_safe=False
)

